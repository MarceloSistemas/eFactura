Imports System
Imports System.Collections
Imports System.Configuration


Public Class ConfigurationReader
    Public Shared Function GetConfigSetting(ByVal strSetting As String) As String
        Dim strEnvironment As String = System.Environment.GetEnvironmentVariable("GMIServer").ToString
        Dim objTempTable As IDictionary

        Try
            objTempTable = CType(ConfigurationSettings.GetConfig(strEnvironment), IDictionary)
            Return CType(objTempTable(strSetting), String)
        Catch Ex As Exception
            Throw
        Finally
            objTempTable = Nothing
        End Try
    End Function
End Class

