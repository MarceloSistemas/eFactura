Option Strict On
Option Explicit On 

Imports System
Imports System.Configuration
Imports System.ComponentModel
Imports System.Data
Imports System.Security.Principal

Imports GotDotNet.ApplicationBlocks.Data

Public Class DataAccess
    Implements IDisposable

    Private m_objConnection As IDbConnection
    Private m_objTransaction As IDbTransaction
    Private m_blnDisposed As Boolean = False
    Private m_blnInTransaction As Boolean = False
    Private m_objAdoHelper As AdoHelper
    'Private m_Parameters As New Hashtable

    Public ReadOnly Property Transaction() As IDbTransaction
        Get
            Return m_objTransaction
        End Get
    End Property

    Public Property commandTimeOut() As Integer
        Get
            Return m_objAdoHelper.commandTimeOut
        End Get
        Set(ByVal Value As Integer)
            m_objAdoHelper.commandTimeOut = Value
        End Set
    End Property


    Public ReadOnly Property InTransaction() As Boolean
        Get
            Return m_blnInTransaction
        End Get
    End Property
    Public Function GetAdoHelper() As AdoHelper
        Dim strProviderAssembly As String = ConfigurationSettings.AppSettings("AdoHelperAssembly")
        Dim strProviderClass As String = ConfigurationSettings.AppSettings("AdoHelperClass")
        Return AdoHelper.CreateHelper(strProviderAssembly, strProviderClass)
        'Return New GotDotNet.ApplicationBlocks.Data.SqlServer
    End Function
    Public Shared Function GetConnectionString() As String
        Dim strConnectionString As String = ""
        Dim strMachineName As String = ""
        Try
            strMachineName = Environment.MachineName
            Try
                strConnectionString = ConfigurationSettings.AppSettings("ConnectionString" + strMachineName)
                If strConnectionString = "" Then
                    Throw New Exception("ConnectionString" + strMachineName + " Key is missing in Web.Config")
                Else
                    Return strConnectionString
                End If

            Catch ex As Exception
                Throw New Exception("ConnectionString" + strMachineName + " Key is missing in Web.Config")
            End Try
        Catch ex As Exception
            Try
                strConnectionString = ConfigurationSettings.AppSettings("ConnectionString")
                If strConnectionString = "" Then
                    If strMachineName <> "" Then
                        Throw New Exception(ex.Message)
                    Else
                        Throw New Exception("Can't read MachineName so ConnectionString Key is missing in Web.Config ")
                    End If
                Else
                    Return strConnectionString
                End If
            Catch ex1 As Exception
                If strMachineName <> "" Then
                    Throw New Exception(ex.Message)
                Else
                    Throw New Exception("Can't read MachineName so ConnectionString Key is missing in Web.Config ")
                End If
            End Try
        End Try

    End Function
    Public Sub New(ByVal strConnectionString As String, ByVal strProviderAssembly As String, ByVal strProviderClass As String)

        Try
            m_objAdoHelper = AdoHelper.CreateHelper(strProviderAssembly, strProviderClass)
            m_objConnection = m_objAdoHelper.GetConnection(strConnectionString)
        Catch ex As Exception
            If Not m_objAdoHelper Is Nothing Then
                m_objAdoHelper = Nothing
            End If

            ''ExceptionManager.Publish(ex)
            Throw ex

        End Try
    End Sub
    Public Sub New()
        Try
            Try
                m_objAdoHelper = GetAdoHelper()
                m_objConnection = m_objAdoHelper.GetConnection(GetConnectionString())
            Catch ex As Exception
                If Not m_objAdoHelper Is Nothing Then
                    m_objAdoHelper = Nothing
                End If
                Throw ex
            End Try
        Catch ex As Exception
            ''ExceptionManager.Publish(ex)
            Throw ex
        End Try
    End Sub
    Public Overloads Sub Dispose() Implements IDisposable.Dispose
        CleanUpResources()
        GC.SuppressFinalize(Me)
    End Sub
    Private Sub CleanUpResources()
        If Not m_blnDisposed Then
            If Not m_objAdoHelper Is Nothing Then
                m_objAdoHelper = Nothing
            End If
        End If
        m_blnDisposed = True
    End Sub
    Public Sub BeginTransaction()
        If Me.m_blnInTransaction Then
            Dim ex As Exception = New Exception("Begin Transaction failed already in trasaction")
            ''ExceptionManager.Publish(ex)
            Throw ex
        Else
            Try
                m_objConnection.Open()
                m_objTransaction = m_objConnection.BeginTransaction()
                Me.m_blnInTransaction = True
            Catch ex As Exception
                ''ExceptionManager.Publish(ex)
                Throw ex
            End Try
        End If
    End Sub
    Public Sub CommitTransaction()
        If Not Me.m_blnInTransaction Then
            Dim ex As Exception = New Exception("Commit Transaction failed not in trasaction")
            ''ExceptionManager.Publish(ex)
            Throw ex
        Else
            Try
                m_objTransaction.Commit()
                m_objConnection.Close()
                Me.m_blnInTransaction = False
            Catch ex As Exception
                ''ExceptionManager.Publish(ex)
                Throw ex
            End Try
        End If
    End Sub
    Public Sub RollbackTransaction()
        If Not Me.m_blnInTransaction Then
            Dim ex As Exception = New Exception("Rollback Transaction failed not in trasaction")
            ''ExceptionManager.Publish(ex)
            Throw ex
        Else
            Try
                m_objTransaction.Rollback()
                m_objConnection.Close()
                Me.m_blnInTransaction = False
            Catch ex As Exception
                ''ExceptionManager.Publish(ex)
                Throw ex
            End Try
        End If
    End Sub
    Public Function GetUserLoginName() As String

        'Dim strUser As String = WindowsIdentity.GetCurrent().Name().ToUpper()
        'Return strUser
        Return System.Threading.Thread.CurrentPrincipal.Identity.Name.ToUpper()

    End Function

#Region "FillDataSet"
    Public Sub FillDataSet(ByVal dstDataSetToFill As DataSet, ByVal dstFilledDataSet As DataSet)
        If (dstDataSetToFill.Tables.Count <> dstFilledDataSet.Tables.Count) Then
            Dim ex As Exception = New Exception("Tables count are diferent in FillDataSet method")
            ''ExceptionManager.Publish(ex)
            Throw ex
        Else
            For intIndex As Integer = 0 To dstFilledDataSet.Tables.Count - 1
                dstFilledDataSet.Tables(intIndex).TableName = dstDataSetToFill.Tables(intIndex).TableName
            Next
            dstDataSetToFill.Merge(dstFilledDataSet)
        End If

    End Sub
    Public Sub FillDataSet(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dstDataSetToFill As DataSet)
        FillDataSet(dstDataSetToFill, ExecuteDataSet(objCommandType, strSql, CType(Nothing, IDataParameter())))
    End Sub
    Public Sub FillDataSet(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dstDataSetToFill As DataSet, ByVal ParamArray aryParameterValues() As Object)
        FillDataSet(dstDataSetToFill, ExecuteDataSet(objCommandType, strSql, aryParameterValues))
    End Sub
    Public Sub FillDataSet(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dstDataSetToFill As DataSet, ByVal ParamArray aryParameters() As IDataParameter)
        FillDataSet(dstDataSetToFill, ExecuteDataSet(objCommandType, strSql, aryParameters))
    End Sub
    Public Sub FillDataSet(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dstDataSetToFill As DataSet, ByVal dtrDataRow As DataRow)
        FillDataSet(dstDataSetToFill, ExecuteDataSet(objCommandType, strSql, dtrDataRow))
    End Sub

#End Region

#Region "ExecuteDataSet"
    Public Function ExecuteDataSet(ByVal objCommandType As CommandType, ByVal strSql As String) As DataSet
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteDataset(m_objTransaction, objCommandType, strSql)
            Else
                Return m_objAdoHelper.ExecuteDataset(m_objConnection, objCommandType, strSql)
            End If
        Catch ex As Exception
            ''ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try

    End Function
    Public Function ExecuteDataSet(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal ParamArray aryParameterValues() As Object) As DataSet
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteDataset(m_objTransaction, strSql, aryParameterValues)
            Else
                Return m_objAdoHelper.ExecuteDataset(m_objConnection, strSql, aryParameterValues)
            End If

        Catch ex As Exception
            ''ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function
    Public Function ExecuteDataSet(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dtrDataRow As DataRow) As DataSet
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteDataset(m_objTransaction, strSql, dtrDataRow)
            Else
                Return m_objAdoHelper.ExecuteDataset(m_objConnection, strSql, dtrDataRow)
            End If

        Catch ex As Exception
            ''ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function
    Public Function ExecuteDataSet(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal ParamArray aryParameters() As IDataParameter) As DataSet
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteDataset(m_objTransaction, objCommandType, strSql, aryParameters)
            Else
                Return m_objAdoHelper.ExecuteDataset(m_objConnection, objCommandType, strSql, aryParameters)
            End If

        Catch ex As Exception
            ''ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try

    End Function

#End Region

#Region "ExecuteNonQuery"
    Public Function ExecuteNonQuery(ByVal objCommandType As CommandType, ByVal strSql As String) As Integer
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteNonQuery(m_objTransaction, objCommandType, strSql)
            Else
                Return m_objAdoHelper.ExecuteNonQuery(m_objConnection, objCommandType, strSql)
            End If

        Catch ex As Exception
            ''ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function
    Public Function ExecuteNonQuery(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal ParamArray aryParameterValues() As Object) As Integer
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteNonQuery(m_objTransaction, strSql, aryParameterValues)
            Else
                Return m_objAdoHelper.ExecuteNonQuery(m_objConnection, strSql, aryParameterValues)
            End If

        Catch ex As Exception
            Throw ex
        Finally
        End Try
    End Function


    Public Function ExecuteNonQuery(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dtrDataRow As DataRow, ByVal parameters As QueryParametersCollection) As Integer
        Try
            Dim intReturn As Integer = 0
            Dim arParameters() As IDataParameter = Me.GetIDataParamters(parameters)
            If m_blnInTransaction Then
                intReturn = m_objAdoHelper.ExecuteNonQuery(m_objTransaction, objCommandType, strSql, dtrDataRow, arParameters)
            Else
                intReturn = m_objAdoHelper.ExecuteNonQuery(m_objConnection, objCommandType, strSql, dtrDataRow, arParameters)
            End If

            Return intReturn
        Catch ex As Exception
            Throw ex
        Finally
        End Try
    End Function

    Public Function ExecuteNonQuery(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dtrDataRow As DataRow) As Integer
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteNonQueryTypedParams(m_objTransaction, strSql, dtrDataRow)
            Else
                Return m_objAdoHelper.ExecuteNonQueryTypedParams(m_objConnection, strSql, dtrDataRow)

            End If

        Catch ex As Exception
            ''ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function
    Public Function ExecuteNonQuery(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal aryParameters() As IDataParameter) As Integer
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteNonQuery(m_objTransaction, objCommandType, strSql, aryParameters)
            Else
                Return m_objAdoHelper.ExecuteNonQuery(m_objConnection, objCommandType, strSql, aryParameters)
            End If

        Catch ex As Exception
            Throw ex
        Finally
        End Try
    End Function




#End Region

#Region "ExecuteScalar"
    Public Function ExecuteScalar(ByVal objCommandType As CommandType, ByVal strSql As String) As Object
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteScalar(m_objTransaction, objCommandType, strSql)
            Else
                Return m_objAdoHelper.ExecuteScalar(m_objConnection, objCommandType, strSql)
            End If

        Catch ex As Exception
            'ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function
    Public Function ExecuteScalar(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal ParamArray aryParameterValues() As Object) As Object
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteScalar(m_objTransaction, strSql, aryParameterValues)
            Else
                Return m_objAdoHelper.ExecuteScalar(m_objConnection, strSql, aryParameterValues)
            End If

        Catch ex As Exception
            'ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function
    Public Function ExecuteScalar(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal dtrDataRow As DataRow) As Object
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteScalarTypedParams(m_objTransaction, strSql, dtrDataRow)
            Else
                Return m_objAdoHelper.ExecuteScalarTypedParams(m_objConnection, strSql, dtrDataRow)
            End If
        Catch ex As Exception
            'ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function
    Public Function ExecuteScalar(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal aryParameters() As IDataParameter) As Object
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteScalar(m_objTransaction, objCommandType, strSql, aryParameters)
            Else
                Return m_objAdoHelper.ExecuteScalar(m_objConnection, objCommandType, strSql, aryParameters)
            End If
        Catch ex As Exception
            'ExceptionManager.Publish(ex)
            Throw ex
        Finally
        End Try
    End Function

    Public Function ExecuteScalar(ByVal objCommandType As CommandType, ByVal strSql As String, ByVal parameters As QueryParametersCollection) As Object
        Try
            If m_blnInTransaction Then
                Return m_objAdoHelper.ExecuteScalar(m_objTransaction, objCommandType, strSql, Me.GetIDataParamters(parameters))
            Else
                Return m_objAdoHelper.ExecuteScalar(m_objConnection, objCommandType, strSql, Me.GetIDataParamters(parameters))
            End If

        Catch ex As Exception
            Throw ex
        Finally
        End Try
    End Function


    Protected Function GetIDataParamters(ByVal queryParams As QueryParametersCollection) As IDataParameter()
        Dim parameters(queryParams.Count - 1) As IDataParameter
        For intIndex As Integer = 0 To queryParams.Count - 1
            parameters(intIndex) = m_objAdoHelper.GetParameter(queryParams.Item(intIndex).ParameterName, queryParams.Item(intIndex).ParameterValue)
            parameters(intIndex).Direction = queryParams.Item(intIndex).ParameterDirection
        Next

        Return parameters
    End Function
#End Region



End Class



Public Class ConfigurationReader
    Public Shared Function GetConfigSetting(ByVal strSetting As String) As String
        Dim strEnvironment As String = System.Environment.GetEnvironmentVariable("GMIServer").ToString
        Dim objTempTable As IDictionary

        Try
            objTempTable = CType(ConfigurationSettings.GetConfig(strEnvironment), IDictionary)
            Return CType(objTempTable(strSetting), String)
        Catch Ex As Exception
            Throw
        Finally
            objTempTable = Nothing
        End Try
    End Function
End Class

Public Class QueryParameter
    Private _parameterName As String
    Private _parameterValue As Object
    Private _parameterDirection As ParameterDirection
    Private _dbType As System.Data.DbType

    Public Property ParameterName() As String
        Get
            Return _parameterName
        End Get
        Set(ByVal Value As String)
            _parameterName = Value
        End Set

    End Property

    Public Property ParameterValue() As Object
        Get
            Return _parameterValue
        End Get
        Set(ByVal Value As Object)
            _parameterValue = Value
        End Set

    End Property
    Public Property DbType() As System.Data.DbType
        Get
            Return _dbType
        End Get
        Set(ByVal Value As System.Data.DbType)
            _dbType = Value
        End Set
    End Property

    Public Property ParameterDirection() As ParameterDirection
        Get
            Return _parameterDirection
        End Get
        Set(ByVal Value As ParameterDirection)
            _parameterDirection = Value
        End Set
    End Property


    Public Sub New(ByVal parameterName As String, ByVal parameterValue As Object)
        Me._parameterName = parameterName
        Me._parameterValue = parameterValue
        Me._parameterDirection = ParameterDirection.Input
    End Sub
End Class


Public Class QueryParametersCollection
    Inherits System.Collections.CollectionBase
    Public Sub Add(ByVal parameter As QueryParameter)
        list.Add(parameter)
    End Sub

    Public Sub Add(ByVal parameterName As String, ByVal parameterValue As Object)
        list.Add(New QueryParameter(parameterName, parameterValue))
    End Sub

    Public Sub Remove(ByVal index As Integer)
        List.RemoveAt(index)
    End Sub

    Public ReadOnly Property Item(ByVal index As Integer) As QueryParameter
        Get
            Return CType(List.Item(index), QueryParameter)
        End Get
    End Property

End Class
