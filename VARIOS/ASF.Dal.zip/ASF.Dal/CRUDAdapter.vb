Option Strict On
Option Explicit On 


Public Class CRUDAdapter
    Public Sub New()
        '
        ' TODO: Add constructor logic here
        '
    End Sub

    Public Delegate Sub OnUpdateDataSetEventHandler(ByVal objDataAccess As DataAccess, ByVal dstDataSet As DataSet)
    Public Delegate Sub OnUpdateTableEventHandler(ByVal objDataAccess As DataAccess, ByVal dstTable As DataTable)
    Public Delegate Sub DataRowUpdaterHandler(ByVal objDataAccess As DataAccess, ByVal dtrDataRow As DataRow)

    Public Event PreProcessRow As DataRowUpdaterHandler
    Public Event PostProcessRow As DataRowUpdaterHandler
    Public Event PostUpdateTable As OnUpdateTableEventHandler
    Public Event PreUpdateTable As OnUpdateTableEventHandler
    Public Event PostUpdateDataSet As OnUpdateDataSetEventHandler
    Public Event PreUpdateDataSet As OnUpdateDataSetEventHandler

    Public strSP_PREFIX As String = ""
    Public blnSP_METHOD_FIRST As Boolean = False
    Public blnUsesStoredProcedures As Boolean = True
    Public Function GetList(ByVal dstDataSet As DataSet, ByVal ParamArray aryParameterValues() As Object) As DataSet

        Dim objDataAccess As New DataAccess
        Try
            Dim strProcName As String = dstDataSet.Tables(0).TableName + "_LST"
            objDataAccess = New DataAccess

            If aryParameterValues Is Nothing Then
                objDataAccess.FillDataSet(CommandType.StoredProcedure, strProcName, dstDataSet)
            Else
                objDataAccess.FillDataSet(CommandType.StoredProcedure, strProcName, dstDataSet, aryParameterValues)
            End If

            Return dstDataSet
        Catch ex As Exception
            Throw ex
        Finally
            If Not objDataAccess Is Nothing Then
                objDataAccess.Dispose()
                objDataAccess = Nothing
            End If

        End Try
    End Function

    Public Function GetFixedData(ByVal dstDataSet As DataSet, ByVal objParameter As Object) As DataSet
        Dim strProcName As String = dstDataSet.Tables(0).TableName + "_LOV"
        Dim objDataAccess As New DataAccess
        Try
            objDataAccess = New DataAccess
            If objParameter Is Nothing Then
                objDataAccess.FillDataSet(CommandType.StoredProcedure, strProcName, dstDataSet)
            Else
                objDataAccess.FillDataSet(CommandType.StoredProcedure, strProcName, dstDataSet, objParameter)
            End If
            Return dstDataSet
        Catch ex As Exception
            'ExceptionManager.Publish(ex)
            Throw ex
        Finally
            If Not objDataAccess Is Nothing Then
                objDataAccess.Dispose()
                objDataAccess = Nothing
            End If

        End Try
    End Function

    Public Function GetRecord(ByVal dstDataSet As DataSet, ByVal objParameter As Object) As DataSet

        Dim objDataAccess As New DataAccess
        Try
            objDataAccess = New DataAccess

            Dim strProcName As String = dstDataSet.Tables(0).TableName + "_SEL"
            If objParameter Is Nothing Then
                objDataAccess.FillDataSet(CommandType.StoredProcedure, strProcName, dstDataSet)
            Else
                objDataAccess.FillDataSet(CommandType.StoredProcedure, strProcName, dstDataSet, objParameter)
            End If


            Return dstDataSet
        Catch ex As Exception
            'ExceptionManager.Publish(ex)
            Throw ex
        Finally
            If Not objDataAccess Is Nothing Then
                objDataAccess.Dispose()
                objDataAccess = Nothing
            End If

        End Try
    End Function

    Public Sub UpdateDataSet(ByVal dstDataSet As DataSet)
        UpdateDataSet(dstDataSet, New DataAccess)
    End Sub

    Public Sub UpdateDataSet(ByVal dstDataSet As DataSet, ByVal objDataAccess As DataAccess)

        Dim dttDataTable As DataTable
        Try
            objDataAccess.BeginTransaction()
            RaiseEvent PreUpdateDataSet(objDataAccess, dstDataSet)
            For Each dttDataTable In dstDataSet.Tables
                RaiseEvent PreUpdateTable(objDataAccess, dttDataTable)
                UpdateDataTable(objDataAccess, dttDataTable)
                RaiseEvent PostUpdateTable(objDataAccess, dttDataTable)
            Next
            RaiseEvent PostUpdateDataSet(objDataAccess, dstDataSet)
            objDataAccess.CommitTransaction()
        Catch ex As Exception
            If Not objDataAccess Is Nothing Then
                objDataAccess.RollbackTransaction()
            End If
            'ExceptionManager.Publish(ex)
            Throw ex
        Finally
            If Not objDataAccess Is Nothing Then
                objDataAccess.Dispose()
                objDataAccess = Nothing
            End If
        End Try
    End Sub
    Public Sub UpdateDataTable(ByVal objDataAcces As DataAccess, ByVal dttDataTable As DataTable)
        Dim dtrDataRow As DataRow
        For Each dtrDataRow In dttDataTable.Rows
            UpdateDataRow(objDataAcces, dtrDataRow)
        Next
    End Sub

    Public Sub UpdateDataRow(ByVal objDataAcces As DataAccess, ByVal dtrDataRow As DataRow)
        Dim strTableName As String = dtrDataRow.Table.TableName

        If blnSP_METHOD_FIRST Then
            UpdateDataRow(objDataAcces, dtrDataRow, strSP_PREFIX + "INSERT_" + strTableName, strSP_PREFIX + "UPDATE_" + strTableName, strSP_PREFIX + "DELETE_" + strTableName)
        Else
            UpdateDataRow(objDataAcces, dtrDataRow, strSP_PREFIX + strTableName + "_INS", strSP_PREFIX + strTableName + "_UPDT", strSP_PREFIX + strTableName + "_DEL")
        End If

    End Sub

    Public Sub UpdateDataRow(ByVal objDataAcces As DataAccess, ByVal dtrDataRow As DataRow, ByVal strInserSPName As String, ByVal strUpdateSPName As String, ByVal strDeleteSPName As String)
        RaiseEvent PreProcessRow(objDataAcces, dtrDataRow)
        Dim dataRowState As dataRowState = dtrDataRow.RowState
        If blnUsesStoredProcedures Then

            Select Case dtrDataRow.RowState
                Case dataRowState.Added
                    objDataAcces.ExecuteNonQuery(CommandType.StoredProcedure, strInserSPName, dtrDataRow)
                Case dataRowState.Modified
                    objDataAcces.ExecuteNonQuery(CommandType.StoredProcedure, strUpdateSPName, dtrDataRow)
                Case dataRowState.Deleted
                    Dim blnIsAParentDeleted As Boolean = False
                    Dim drlDataRelation As DataRelation
                    For Each drlDataRelation In dtrDataRow.Table.ParentRelations
                        blnIsAParentDeleted = (blnIsAParentDeleted OrElse dtrDataRow.GetParentRow(drlDataRelation, DataRowVersion.Original).RowState = dataRowState.Deleted)
                    Next
                    If Not blnIsAParentDeleted Then
                        dtrDataRow.RejectChanges()
                        objDataAcces.ExecuteNonQuery(CommandType.StoredProcedure, strDeleteSPName, dtrDataRow)
                        dtrDataRow.Delete()
                    End If
            End Select
        Else
            Dim arParameters As New QueryParametersCollection

            Select Case dtrDataRow.RowState
                Case dataRowState.Added
                    Dim strFields As String = ""
                    Dim strValues As String = ""
                    Dim strAutoIncrementColumn As String = ""
                    For Each objColumn As DataColumn In dtrDataRow.Table.Columns
                        If Not objColumn.AutoIncrement AndAlso Not objColumn.ReadOnly Then
                            strFields = strFields + objColumn.ColumnName + ", "
                            strValues = strValues + "@" + objColumn.ColumnName + ", "
                            arParameters.Add("@" + objColumn.ColumnName, dtrDataRow(objColumn.ColumnName))
                        End If
                        If objColumn.AutoIncrement Then
                            strAutoIncrementColumn = "; set @" + objColumn.ColumnName + " =  SCOPE_IDENTITY()"
                            Dim objQueryParam As New QueryParameter("@" + objColumn.ColumnName, dtrDataRow(objColumn.ColumnName))
                            objQueryParam.ParameterDirection = ParameterDirection.Output
                            arParameters.Add(objQueryParam)
                        End If

                    Next
                    strFields = strFields.Substring(0, strFields.Length - 2)
                    strValues = strValues.Substring(0, strValues.Length - 2)
                    Dim strSQL As String = "insert into " + dtrDataRow.Table.TableName + "(" + strFields + ") values (" + strValues + ")" + strAutoIncrementColumn
                    'objDataAcces.ExecuteNonQuery(CommandType.Text, strSQL, arParameters)
                    objDataAcces.ExecuteNonQuery(CommandType.Text, strSQL, dtrDataRow, arParameters)

                Case dataRowState.Modified

                    Dim strCondition As String = ""
                    Dim strUpdFields As String = ""
                    For Each objColumn As DataColumn In dtrDataRow.Table.PrimaryKey
                        strCondition = strCondition + objColumn.ColumnName + " = @" + objColumn.ColumnName + " and "
                        arParameters.Add("@" + objColumn.ColumnName, dtrDataRow(objColumn.ColumnName))
                    Next

                    For Each objColumn As DataColumn In dtrDataRow.Table.Columns
                        If dtrDataRow.Table.PrimaryKey.IndexOf(dtrDataRow.Table.PrimaryKey, objColumn) = -1 Then
                            If dtrDataRow(objColumn.ColumnName).Equals(dtrDataRow(objColumn.ColumnName, DataRowVersion.Original)) Then
                                strUpdFields = strUpdFields + objColumn.ColumnName + " = @" + objColumn.ColumnName + ", "
                                arParameters.Add("@" + objColumn.ColumnName, dtrDataRow(objColumn.ColumnName))
                            End If
                        End If

                    Next
                    strCondition = strCondition.Substring(0, strCondition.Length - 4)
                    strUpdFields = strUpdFields.Substring(0, strUpdFields.Length - 2)
                    Dim strSQL As String = "update " + dtrDataRow.Table.TableName + " set " + strUpdFields + " where " + strCondition

                    'objDataAcces.ExecuteNonQuery(CommandType.Text, strSQL, arParameters)
                    objDataAcces.ExecuteNonQuery(CommandType.Text, strSQL, dtrDataRow, arParameters)
                Case dataRowState.Deleted
                    dtrDataRow.RejectChanges()
                    Dim strCondition As String = ""
                    For Each objColumn As DataColumn In dtrDataRow.Table.PrimaryKey
                        strCondition = strCondition + objColumn.ColumnName + " = @" + objColumn.ColumnName + " and "
                        arParameters.Add("@" + objColumn.ColumnName, dtrDataRow(objColumn.ColumnName))
                    Next
                    strCondition = strCondition.Substring(0, strCondition.Length - 4)
                    Dim strSQL As String = "delete from " + dtrDataRow.Table.TableName + " where " + strCondition
                    objDataAcces.ExecuteNonQuery(CommandType.Text, strSQL, dtrDataRow, arParameters)
                    dtrDataRow.Delete()

            End Select
        End If
        RaiseEvent PostProcessRow(objDataAcces, dtrDataRow)
    End Sub


End Class
